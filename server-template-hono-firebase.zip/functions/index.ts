import dotenv from 'dotenv'
dotenv.config()

import { setupAxiosInterceptors } from './src/utils/axios.interceptor.js'
setupAxiosInterceptors()

import { Hono } from 'hono'
import { HTTPException } from 'hono/http-exception'
import { onRequest } from 'firebase-functions/v2/https'
import { adapt } from './src/adapters.js'
import { runSyncJob } from './src/services/sync.service.js'
import messageController from './src/controllers/message.js'
import userController from './src/controllers/user.js'
import './src/cronjob.js'
import { randomUUID } from 'crypto'

console.log('[INIT] ✅ API HTTP inicializada com rotas: /ping, /message, /user, /test/cron')

const app = new Hono()
  .get('/ping', (ctx) => {
    console.log('[PING] 🏓 Requisição recebida em /ping')
    return ctx.text('pong!')
  })
  .route('/message', messageController)
  .route('/user', userController)
  .get('/test/cron', async (ctx) => {
    const executionId = randomUUID()
    console.log(`[MANUAL-CRON][${executionId}] 🚀 Execução manual via /test/cron iniciada`)
    try {
      await runSyncJob({ executionId })
      console.log(`[MANUAL-CRON][${executionId}] ✅ Execução manual concluída com sucesso`)
      return ctx.text('✅ Cron executado manualmente.')
    } catch (err: any) {
      console.error(`[MANUAL-CRON][${executionId}] ❌ Erro na execução manual do cron:`, err)
      return ctx.text('❌ Erro na execução manual do cron. Verifique os logs.')
    }
  })
  .onError((err, ctx) => {
    const status = err instanceof HTTPException ? err.status : 500
    console.error('[ERROR] 💥 Erro inesperado:', {
      message: err.message,
      status,
      cause: 'cause' in err ? err.cause : undefined,
    })
    return ctx.json(
      {
        success: false,
        error: err.message || 'Erro interno do servidor',
        cause: 'cause' in err ? err.cause : undefined,
      },
      status
    )
  })

export const server = onRequest(adapt(app))
