import 'dotenv/config'
import { onSchedule } from 'firebase-functions/v2/scheduler'
import { runSyncJob } from './services/sync.service.js'
import { randomUUID } from 'crypto'

/**
 * Captura erros globais silenciosos
 */
process.on('unhandledRejection', (reason) => {
  console.error('[FATAL][GLOBAL] Unhandled Promise rejection:', reason)
})

process.on('uncaughtException', (err) => {
  console.error('[FATAL][GLOBAL] Uncaught Exception:', err)
})

/**
 * Agendamento oficial (produção)
 */
console.log('[INIT] ✅ Função agendada "syncActiveMessages" registrada (1 minuto)')

export const syncActiveMessages = onSchedule(
  {
    schedule: 'every 1 minutes',
    region: 'southamerica-east1',
  },
  async () => {
    const executionId = randomUUID()
    console.log(`[CRON][${executionId}] 🔄 Iniciando execução agendada`)
    try {
      await runSyncJob({ executionId })
      console.log(`[CRON][${executionId}] ✅ Execução finalizada com sucesso`)
    } catch (err) {
      console.error(`[CRON][${executionId}] ❌ Erro na execução do cron job:`, err)
    }
  }
)

/**
 * Execução local (modo emulador)
 */
if (process.env.FUNCTIONS_EMULATOR === 'true') {
  console.log('[DEV][INIT] 🧪 Emulador ativo: iniciando cron a cada 1 minuto')

  setTimeout(() => {
    console.log('[DEV] ✅ setInterval() configurado com sucesso — cron local iniciado')
    setInterval(async () => {
      const executionId = randomUUID()
      console.log(`[DEV][${executionId}] 🔄 Iniciando execução local`)
      try {
        await runSyncJob({ executionId })
        console.log(`[DEV][${executionId}] ✅ Execução local finalizada`)
      } catch (err) {
        console.error(`[DEV][${executionId}] ❌ Erro durante execução local:`, err)
      }
    }, 60_000)
  }, 500) // pequeno delay para garantir que o console mostre o INIT antes
} else {
  console.log('[DEV][INIT] ⚠ Emulador desativado — cron local não será iniciado')
}
