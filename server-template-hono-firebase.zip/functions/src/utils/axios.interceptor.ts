import axios from 'axios'

export function setupAxiosInterceptors() {
  axios.interceptors.request.use((config) => {
    console.log(`[HTTP][REQUEST] → ${config.method?.toUpperCase()} ${config.baseURL || ''}${config.url}`)
    if (config.headers) console.log(`[HTTP][REQUEST] Headers:`, config.headers)
    if (config.data) console.log(`[HTTP][REQUEST] Payload:`, JSON.stringify(config.data, null, 2))
    return config
  })

  axios.interceptors.response.use(
    (response) => {
      console.log(`[HTTP][RESPONSE] ← ${response.status} ${response.config.url}`)
      if (response.data) {
        console.log(`[HTTP][RESPONSE] Body:`, JSON.stringify(response.data, null, 2))
      }
      return response
    },
    (error) => {
      if (error.response) {
        console.error(`[HTTP][ERROR] ← ${error.response.status} ${error.config.url}`)
        console.error(`[HTTP][ERROR] Body:`, JSON.stringify(error.response.data, null, 2))
      } else {
        console.error(`[HTTP][ERROR] Erro na requisição:`, error.message)
      }
      return Promise.reject(error)
    }
  )
}
