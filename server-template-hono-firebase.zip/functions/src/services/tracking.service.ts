import { fetchUsersByPhone } from './braze.service.js'
import { sendBlipTracking } from './sendBlipTracking.service.js'
import { getContactByIdentity } from './blip.service.js'
import { BlipClient } from '@whitewall/blip-sdk'

type SendTrackingsParams = {
  executionId?: string
}

export async function sendTrackingsFromAudience(
  client: BlipClient,
  audience: any[],
  { executionId = 'no-id' }: SendTrackingsParams = {}
) {
  const summary: string[] = []

  for (const contact of audience) {
    const phone = contact.recipient
    const campaignId = contact.CampaignId
    const statusRaw = contact.status
    // MUDANÇA: Agora só retorna status que aconteceram recentemente
    const statuses = extractStatuses(contact)
    const cleanPhone = phone.split('@')[0]

    // Se não houver status recentes, pula este contato
    if (statuses.length === 0) {
      console.log(`[TRACKING][${executionId}] ⏭️ ${phone} | Nenhum evento recente para processar`)
      continue
    }

    console.log(`[TRACKING][${executionId}] → ${phone} | Status atual: ${statusRaw} | Eventos recentes: ${statuses.join(', ')}`)

    try {
      const messageParams = contact.messageParams
      let experienceToUse = ''
      let externalId = ''

      if (messageParams?.experience && messageParams?.externalId) {
        experienceToUse = messageParams.experience
        externalId = messageParams.externalId
        console.log(`[TRACKING][${executionId}] 🟢 Dados do messageParams usados | Experience: ${experienceToUse} | ExternalId: ${externalId}`)
      } else {
        const users = await fetchUsersByPhone(phone)
        const identity = contact.validatedAccount || `${cleanPhone}@wa.gw.msging.net`

        try {
          const contactData = await getContactByIdentity(identity)
          const experienceFromBlip = contactData?.extras?.experience

          if (experienceFromBlip) {
            const userMatch = users.find(u => u.custom_attributes?.experience_name === experienceFromBlip)
            if (userMatch) {
              experienceToUse = experienceFromBlip
              externalId = userMatch.external_id
              console.log(`[TRACKING][${executionId}] 🔵 Experience da Blip usada | Experience: ${experienceToUse} | ExternalId: ${externalId}`)
            } else {
              console.warn(`[TRACKING][${executionId}] ⚠ Experience da Blip não encontrada na Braze: ${experienceFromBlip}`)
            }
          }
        } catch (e: any) {
          console.warn(`[TRACKING][${executionId}] ⚠ Erro ao consultar contato Blip: ${e.message}`)
        }

        if (!experienceToUse || !externalId) {
          const fallbackUser = users.find(u => u.custom_attributes?.experience_name)
          if (fallbackUser) {
            experienceToUse = fallbackUser.custom_attributes.experience_name
            externalId = fallbackUser.external_id
            console.log(`[TRACKING][${executionId}] 🟡 Usando fallback da Braze | Experience: ${experienceToUse} | ExternalId: ${externalId}`)
          } else {
            console.warn(`[TRACKING][${executionId}] ⚠ Nenhum usuário Braze válido encontrado: ${phone}`)
            continue
          }
        }
      }

      for (const statusFinal of statuses) {
        const extras: Record<string, any> = {
          ProfileId: externalId,
          Experience: experienceToUse,
          Phone: cleanPhone,
        }

        if (statusFinal === 'whatsapp-failed' && contact.reasonCode && contact.reasonDescription) {
          extras.reason = {
            code: contact.reasonCode,
            description: contact.reasonDescription,
          }
          console.warn(`[TRACKING][${executionId}] ⚠ Falha reportada | Código: ${contact.reasonCode} | Motivo: ${contact.reasonDescription}`)
        }

        console.log(`[TRACKING][${executionId}] 📤 Enviando tracking | ID: ${externalId} | Categoria: ${statusFinal}`)
        await sendBlipTracking({
          client,
          category: statusFinal,
          externalId,
          experience: experienceToUse,
          extras,
          executionId,
        })

        console.log(`[TRACKING][${executionId}] ✅ Tracking enviada com sucesso`)
      }

      summary.push(`${cleanPhone} → ${statuses.join(', ')} (${experienceToUse})`)

    } catch (err: any) {
      console.error(`[TRACKING][${executionId}] ❌ Erro ao processar ${phone}: ${err.message}`)
    }
  }

  if (summary.length) {
    console.log(`\n[TRACKING][${executionId}] 🧾 Resumo da execução:`)
    summary.forEach(entry => {
      console.log(`  • ${entry}`)
    })
  }
}

/**
 * Extrai apenas os status que mudaram recentemente (dentro da janela de tempo)
 * Isso evita reenviar trackings para eventos antigos
 */
function extractStatuses(contact: any): string[] {
  const statuses: string[] = []
  const currentTime = new Date().getTime()
  // Janela de 2 minutos - ajuste conforme necessário
  // 2 minutos = evita muitas duplicações mas pode perder eventos se o cron falhar
  // 5 minutos = mais seguro mas pode gerar algumas duplicações
  const TIME_WINDOW = 2 * 60 * 1000 
  
  // Verifica cada status e só adiciona se o evento for recente
  if (contact.processed && isRecentEvent(contact.processed, currentTime, TIME_WINDOW)) {
    statuses.push('whatsapp-sent')
    console.log(`[TRACKING] ⏰ Evento SENT é recente: ${contact.processed}`)
  }
  
  if (contact.received && isRecentEvent(contact.received, currentTime, TIME_WINDOW)) {
    statuses.push('whatsapp-delivered')
    console.log(`[TRACKING] ⏰ Evento DELIVERED é recente: ${contact.received}`)
  }
  
  if (contact.read && isRecentEvent(contact.read, currentTime, TIME_WINDOW)) {
    statuses.push('whatsapp-read')
    console.log(`[TRACKING] ⏰ Evento READ é recente: ${contact.read}`)
  }
  
  if (contact.failed && isRecentEvent(contact.failed, currentTime, TIME_WINDOW)) {
    statuses.push('whatsapp-failed')
    console.log(`[TRACKING] ⏰ Evento FAILED é recente: ${contact.failed}`)
  }
  
  return statuses
}

/**
 * Verifica se um evento aconteceu dentro da janela de tempo configurada
 * @param eventDateStr - Data do evento em formato string
 * @param currentTime - Timestamp atual em millisegundos
 * @param window - Janela de tempo em millisegundos
 * @returns true se o evento é recente, false caso contrário
 */
function isRecentEvent(eventDateStr: string, currentTime: number, window: number): boolean {
  try {
    const eventTime = new Date(eventDateStr).getTime()
    const timeDiff = currentTime - eventTime
    // O evento é recente se aconteceu entre 0 e TIME_WINDOW millisegundos atrás
    return timeDiff >= 0 && timeDiff <= window
  } catch (e) {
    console.error(`[TRACKING] ❌ Erro ao parsear data: ${eventDateStr}`, e)
    return false
  }
}