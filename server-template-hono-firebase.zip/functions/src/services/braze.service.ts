// Consulta a API da Braze para buscar dados do usuário por telefone
import axios from 'axios'

export interface BrazeUser {
  external_id: string
  braze_id: string
  email: string
  custom_attributes: {
    experience_name: string
    [key: string]: any
  }
  phone: string
}

export async function fetchUsersByPhone(phone: string): Promise<BrazeUser[]> {
  const payload = {
    phone,
    fields_to_export: ['external_id','email','braze_id','phone','custom_attributes'],
  }

  const res = await axios.post(`${process.env.BRAZE_REST_URL}/users/export/ids`, payload, {
    headers: {
      Authorization: `Bearer ${process.env.BRAZE_API_KEY}`,
      'Content-Type': 'application/json'
    }
  })

  return res.data.users as BrazeUser[]
}
