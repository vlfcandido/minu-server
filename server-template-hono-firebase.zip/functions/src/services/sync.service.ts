import { BlipClient, HttpSender } from '@whitewall/blip-sdk'
import { getCampaignsInPeriod } from './campaign.service.js'
import { getAudienceByCampaign } from './audience.service.js'
import { sendTrackingsFromAudience } from './tracking.service.js'

type RunSyncJobParams = {
  executionId?: string
}

export async function runSyncJob({ executionId = 'no-id' }: RunSyncJobParams): Promise<void> {
  console.log(`[SYNC][${executionId}] ▶ Iniciando cron job`)

  const end = new Date()
  // MUDANÇA: Log agora reflete o período real de busca (6 horas)
  // Isso é apenas para o log - a lógica real está em getCampaignsInPeriod
  const start = new Date(end.getTime() - 6 * 60 * 60 * 1000) // 6 horas
  console.log(`[SYNC][${executionId}] 📅 Período de busca: ${start.toISOString()} → ${end.toISOString()}`)

  // Validação das variáveis de ambiente
  const apiKey = process.env.BOT_API_TOKEN
  const botId = process.env.BOT_CONTRACT

  console.log(`[ENV][${executionId}] BOT_API_TOKEN: ${apiKey ? '[OK]' : '[FALTANDO]'}`)
  console.log(`[ENV][${executionId}] BOT_CONTRACT: ${botId ? `[${botId}]` : '[FALTANDO]'}`)

  // Configuração do cliente Blip
  const sender = new HttpSender(apiKey!, botId!)
  console.log(`[BLIP][${executionId}] URL base utilizada: ${sender['baseUri']}/commands`)

  const client = new BlipClient(sender)

  try {
    // 1. Busca campanhas das últimas 6 horas
    console.log(`[SYNC][${executionId}] 🚀 Buscando campanhas no período...`)
    const campaigns = await getCampaignsInPeriod(client, { executionId })
    console.log(`[SYNC][${executionId}] 📊 ${campaigns.length} campanha(s) encontrada(s)`)

    // 2. Para cada campanha, busca audiência e envia trackings
    for (const campaign of campaigns) {
      console.log(`[SYNC][${executionId}] ▶ Campanha ${campaign.id}: buscando audiência...`)
      const audience = await getAudienceByCampaign(client, campaign.id, { executionId })
      console.log(`[SYNC][${executionId}] 👥 ${audience.length} contato(s) encontrado(s)`)

      // 3. Envia trackings apenas para eventos recentes (últimos 2 minutos)
      console.log(`[SYNC][${executionId}] 📤 Enviando trackings da campanha ${campaign.id}...`)
      await sendTrackingsFromAudience(client, audience, { executionId })
    }

    console.log(`[SYNC][${executionId}] ✅ Cron job finalizado com sucesso`)
  } catch (error: any) {
    console.error(`[SYNC][${executionId}] ❌ Erro durante execução do cron job:`, error)

    if (error?.cause) {
      console.error(`[SYNC][${executionId}] ⚠ Causa interna:`, error.cause)
    }

    throw error
  }
}