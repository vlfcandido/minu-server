import { v4 as uuidv4 } from 'uuid'
import axios from 'axios'
import { BlipClient } from '@whitewall/blip-sdk'
import { config } from 'dotenv'

config()

type CreateTrackingParams = {
  client?: BlipClient
  category: string
  externalId: string
  experience: string
  extras?: Record<string, any>
  executionId?: string
}

export async function sendBlipTracking({
  client,
  category,
  externalId,
  experience,
  extras = {},
  executionId = 'no-id',
}: CreateTrackingParams): Promise<any> {
  const method = process.env.BLIP_REQUEST_METHOD

  const message = {
    id: uuidv4(),
    to: 'postmaster@analytics.msging.net',
    type: 'application/vnd.iris.eventTrack+json',
    content: {
      category,
      action: externalId,
      extras: {
        ProfileId: externalId,
        Experience: experience,
        ...extras,
      },
    },
  }

  console.log(`[TRACKING][${executionId}] Dados de tracking →`, JSON.stringify(message, null, 2))

  if (method === 'native') {
    // Enviar via Axios usando /commands com URI personalizada
    const response = await axios.post(
      'https://minutrade.http.msging.net/commands',
      {
        id: message.id,
        to: message.to,
        method: 'set',
        uri: '/event-track',
        type: message.type,
        resource: message.content,
      },
      {
        headers: {
          Authorization: `Key ${process.env.BOT_API_TOKEN}`,
          'Content-Type': 'application/json',
        },
      }
    )

    console.log(`[TRACKING][${executionId}] ✅ Resposta do Blip (nativo):`, response.data)
    return response.data
  } else {
    // Enviar via SDK
    if (!client) throw new Error('BlipClient não fornecido para envio via SDK.')
    await client.sendMessage(message)
    console.log(`[TRACKING][${executionId}] ✅ Enviado via SDK`)
    return { success: true }
  }
}
