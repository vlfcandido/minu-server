import { BlipClient } from '@whitewall/blip-sdk'

type GetCampaignsInPeriodParams = {
  executionId?: string
}

export async function getCampaignsInPeriod(
  client: BlipClient,
  { executionId = 'no-id' }: GetCampaignsInPeriodParams = {}
) {
  const end = new Date()
  // MUDANÇA: Aumentamos a janela de busca de 60 segundos para 6 horas
  // Isso garante que pegamos eventos de read que podem chegar horas depois
  const start = new Date(end.getTime() - 6 * 60 * 60 * 1000) // últimas 6 horas

  console.log(`[CAMPAIGN][${executionId}] 🔍 Verificando campanhas entre ${start.toISOString()} e ${end.toISOString()}`)

  // Busca campanhas criadas no dia de início (API da Blip requer data no formato YYYY-MM-DD)
  const createdDate = start.toISOString().split('T')[0]
  const all = await client.activecampaign.getCampaignsSummaries({ createdDate })

  console.log(`[DEBUG][${executionId}] 🗂 Campanhas retornadas pela API no dia ${createdDate} (${all.length}):`)

  // Log detalhado de todas as campanhas para debug
  for (const c of all) {
    const sendDate = new Date(c.sendDate)
    const isInPeriod = sendDate >= start && sendDate <= end
    const statusTag = isInPeriod ? '[✔ NO PERÍODO]' : '[✘ FORA DO PERÍODO]'
    const status = c.status || 'sem status'

    console.log(`[DEBUG][${executionId}] ${statusTag} Campanha ID: ${c.id}`)
    console.log(`  • Nome: ${c.name}`)
    console.log(`  • Envio: ${c.sendDate}`)
    console.log(`  • Status: ${status}`)
    console.log(`  • Template: ${c.messageTemplate}`)
    console.log(`  • Canal: ${c.channelType}`)

    if (Array.isArray(c.statusAudience) && c.statusAudience.length > 0) {
      console.log(`  • Audiência (${c.statusAudience.length} contato(s)):`)
      for (const audience of c.statusAudience) {
        console.log(`    - ${audience.recipientIdentity} | Status: ${audience.status} | Número: ${audience.numberStatus}`)
      }
    } else {
      console.log(`  • Audiência: [nenhum contato]`)
    }
    console.log('') // espaço entre campanhas
  }

  // Filtra apenas campanhas dentro do período de 6 horas
  const filtered = all.filter((c) => {
    const sendDate = new Date(c.sendDate)
    return sendDate >= start && sendDate <= end
  })

  if (filtered.length === 0) {
    console.log(`[CAMPAIGN][${executionId}] ⚠ Nenhuma campanha encontrada no período de 6 horas`)
  } else {
    console.log(`[CAMPAIGN][${executionId}] 📊 ${filtered.length} campanha(s) encontrada(s) no período:`)
    for (const c of filtered) {
      console.log(`[CAMPAIGN][${executionId}] → ID: ${c.id} | Nome: ${c.name} | Envio: ${c.sendDate}`)
    }
  }

  return filtered
}