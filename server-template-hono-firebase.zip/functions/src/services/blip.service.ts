import axios from 'axios'

export async function getContactByIdentity(identity: string) {
  const url = 'https://minutrade.http.msging.net/commands'

  const response = await axios.post(url, {
    id: Math.random().toString(),
    to: 'postmaster@msging.net',
    method: 'get',
    uri: `/contacts/${identity}`,
  }, {
    headers: {
      Authorization: `Key ${process.env.BOT_API_TOKEN}`,
      'Content-Type': 'application/json',
    },
  })

  return response.data.resource
}
