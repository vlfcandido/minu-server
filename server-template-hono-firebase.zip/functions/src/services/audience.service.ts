import { BlipClient } from '@whitewall/blip-sdk'

type GetAudienceByCampaignParams = {
  executionId?: string
}

export async function getAudienceByCampaign(
  client: BlipClient,
  campaignId: string,
  { executionId = 'no-id' }: GetAudienceByCampaignParams = {}
) {
  const url = `/commands/activecampaign/${campaignId}/audience`
  console.log(`[HTTP][REQUEST][${executionId}] → GET ${url}`)

  try {
    const audience = await client.activecampaign.getAudience(campaignId)

    console.log(`[HTTP][RESPONSE][${executionId}] ← 200 ${url}`)
    console.log(`[HTTP][RESPONSE][${executionId}] Body:`, JSON.stringify(audience, null, 2))

    if (!audience.length) {
      console.log(`[AUDIENCE][${executionId}] ⚠ Nenhum contato retornado para a campanha ${campaignId}`)
      return []
    }

    console.log(`[AUDIENCE][${executionId}] 👥 ${audience.length} contato(s) encontrado(s):`)
    for (const contact of audience) {
      console.log(`[AUDIENCE][${executionId}] → ${contact.recipient} | Status: ${contact.status}`)
    }

    return audience
  } catch (error: any) {
    const status = error?.response?.status || 'N/A'
    console.error(`[HTTP][ERROR][${executionId}] ← ${status} ${url}`)
    if (error?.response?.data) {
      console.error(`[HTTP][ERROR][${executionId}] Body:`, JSON.stringify(error.response.data, null, 2))
    } else {
      console.error(`[HTTP][ERROR][${executionId}]`, error.message)
    }
    throw error
  }
}
