import { Hono } from 'hono'
import { runSyncJob } from '../services/sync.service.js'
import { randomUUID } from 'crypto'

export default new Hono().post('/send', async (ctx) => {
  const executionId = randomUUID()
  console.log(`[MANUAL-CRON][${executionId}] ▶ Requisição POST /message/send iniciada`)

  try {
    await runSyncJob({ executionId })
    console.log(`[MANUAL-CRON][${executionId}] ✅ Execução manual concluída com sucesso`)
    return ctx.text('[CRON] Execução manual finalizada com sucesso.')
  } catch (err: any) {
    console.error(`[MANUAL-CRON][${executionId}] ❌ Erro ao executar runSyncJob:`, err)
    return ctx.text('[ERRO] Falha ao executar cron.', 500)
  }
})
